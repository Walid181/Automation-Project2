package testCases;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import base.DriverSetup;
import pageObjects.P001_verifyCheckboxAndRadioButton;

public class TC001_checkBoxAndRadioButton extends DriverSetup {
	public static String baseUrl = "https://jqueryui.com/checkboxradio/";

	@Test
	public static void checkBoxAndRadioButtonInIFrame() throws InterruptedException {
		driver.get(baseUrl);
		new WebDriverWait(driver, Duration.ofSeconds(5));
		driver.manage().window().maximize();

		Thread.sleep(2000);
		// Switch to frame
		driver.switchTo().frame(0);
		
		P001_verifyCheckboxAndRadioButton learningPageObject=new P001_verifyCheckboxAndRadioButton(driver);
		
		learningPageObject.clickRadioButton();
		learningPageObject.clickCheckBox();
		Thread.sleep(2000);
		
		driver.switchTo().defaultContent();
		// Close Site
		driver.close();
		

	}
}
